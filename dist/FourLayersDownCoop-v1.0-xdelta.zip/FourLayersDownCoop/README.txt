FOUR LAYERS DOWN CO-OP  v1.0  (English — Español: LEEME.txt)
Mod for Five Nights at Frickbear's 3 + Four Layers Down, VERSION 2.1.5 (Windows)
================================================================================
Local co-op for Brave Tower: a main player and a helper on the same keyboard.
In game it shows up as the "Co-op Mode" card (Solo Mode icon with "2P").


FEATURES
--------
  - Each player picks their own guard (no duplicates), with 3 shared lives
    (2 for the main player's guard, 1 for the helper's).
  - Switch the active guard on the animatronic selection screen, Party Mode
    style. Jeremy, Vanessa, Michael and Vannabelle's roster passives only
    apply to the ACTIVE guard. Every other passive applies for BOTH guards
    while they are alive.
  - The helper's guard shows up in the monitor reflection, to the right of
    the main player.
  - Dollie's healing works for both guards.
  - Co-op runs are saved: "Continue" keeps both guards and the helper keys.


CONTROLS
--------
  Guard select:  main player clicks a guard ("1P");
                 helper moves the "2P" frame with the ARROW KEYS.
  Animatronic selection:  helper LEFT/RIGHT switches the active guard
                          (main player can also click the guard icons).
  Office:
    MAIN PLAYER  mouse + usual keys (monitor, flashlight, turn around...).
                 Doors, mask and fan are the helper's job.
    HELPER       LEFT = left door    RIGHT = right door
                 DOWN = mask         UP    = fan
  Original rules still apply: no mask while the monitor is up and no monitor
  while the mask is on (you hear an error sound).


INSTALL (.xdelta patch)
-----------------------
Requires the ORIGINAL v2.1.5 game with no other mods. Its data.win SHA-256 is
c254b690b0e2ac7f52914fecc24d4753106a3daf893b11252c3c43ec5ae0df5b

1. Close the game and back up data.win (e.g. data.win.original).
2. Open DeltaPatcher (see the GameBanana tutorial "How to install a
   DeltaPatcher mod").
3. Original file: the data.win next to Frickbears3.exe.
   XDelta patch:  FourLayersDownCoop-v1.0.xdelta
4. Click "Apply patch". If it fails, your data.win isn't the original 2.1.5.


UNINSTALL
---------
Delete the patched data.win and rename your backup back to data.win.
(A saved Co-op run will continue as a normal Solo run on the original game.)


NOTES
-----
  - Some cheap keyboards drop keys when many are pressed at once. A second
    USB keyboard for the helper fixes it, because the game reads every
    keyboard.
  - On-screen key hints still show the main player's keys.

Patched data.win SHA-256:
96e9eb577289de392e4660929d522a43b2d52535a917ed4a94d65be017111ac9

Five Nights at Frickbear's 3 is by SpookyRick. This is an unofficial fan mod.
